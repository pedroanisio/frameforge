#!/usr/bin/env python3
"""A 3D surface (inflated relief) of a colour Batman render — built with the SDK.

Unlike the flat gorilla stencil, this input is a *shaded colour render* with a
clean alpha channel, so we can do better than a monochrome height-ramp:

  * geometry  — the alpha mask is inflated by a Euclidean distance transform
    (``z = sqrt(2d - d^2)``) so the bust gains rounded volume, then modulated by
    the figure's own luminance (highlights rise, the black cape/bat-symbol sink)
    for surface detail.
  * albedo    — each projected face is painted with the *original pixel colour*
    sampled from the render, then Lambert-lit, so the grey suit, black cape and
    gold belt survive onto the 3D surface.

Same projection pipeline as ``examples/sdk_3d_scene.py`` and
``examples/king_kong_gorilla_3d_surface.py``: Scene3D + a perspective Camera,
with shading baked author-side over the public face list. A turntable strip
(same geometry, fixed light, orbited camera) shows the volume from three angles.

Run from the repository root (the ``vision`` group ships numpy + Pillow + cv2)::

    uv run --group vision  python examples/batman_3d_surface.py
"""
from __future__ import annotations

import math
import os
import sys

import cv2
import numpy as np
from PIL import Image, ImageFilter

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, ROOT)
_shadow = sys.modules.get("framegraph")
if _shadow is not None and not hasattr(_shadow, "__path__"):
    del sys.modules["framegraph"]

from framegraph.sdk import (  # noqa: E402
    Camera,
    DocumentBuilder,
    Scene3D,
    Vec3,
    linear_gradient,
    rgba,
    serialize,
)
from framegraph.sdk.validate import validate_static_rules  # noqa: E402

SOURCE_IMAGE = os.path.join(ROOT, "batman__dc__render_v2_by_eternalashen_dkfkwpl-414w-2x.png")

# --- relief tuning -------------------------------------------------------- #
TARGET_H = 132          # heightfield rows; columns follow the image aspect
SUPER = 3               # super-sample factor for a smooth distance transform
DEPTH = 0.44            # relief depth as a fraction of the unit Y span
ALPHA_BIN = 40          # alpha above this is "figure"
LUM_FLOOR = 0.45        # low-freq shading: dark cape sinks toward this fraction
DETAIL_HP = 0.90        # high-freq shading embossed as fine surface relief
CONTRAST = 1.20         # albedo contrast boost (grey suit vs black cape)
LIFT = 12               # albedo brightness lift
PAD_FRAC = 0.05         # zero-height border so the relief sits on a plinth

# --- look ----------------------------------------------------------------- #
W, H = 1040, 1290
HERO_BOX = [60, 138, 920, 800]
TURN_H = 64             # coarse grid for the turntable thumbnails
TURN_AZIMUTHS = (-30.0, 0.0, 30.0)
SANS = ["DejaVu Sans", "Arial", "sans-serif"]
MONO = ["DejaVu Sans Mono", "Courier New", "monospace"]
BG_TOP, BG_LOW = "#0a0d14", "#141a26"
PLINTH = (16, 18, 26)   # dark neutral behind / around the figure

LIGHT = (-0.40, 0.66, 0.64)
_ll = math.sqrt(sum(c * c for c in LIGHT))
LIGHT = tuple(c / _ll for c in LIGHT)


# ======================================================================= #
#  colour helpers
# ======================================================================= #
def _hex(r, g, b):
    clamp = lambda v: max(0, min(255, int(round(v))))
    return f"#{clamp(r):02X}{clamp(g):02X}{clamp(b):02X}"


def _tint(rgb, b):
    return _hex(rgb[0] * b, rgb[1] * b, rgb[2] * b)


def _face_normal(verts):
    a, b, c = verts[0], verts[1], verts[2]
    u, v = b - a, c - a
    nx = u.y * v.z - u.z * v.y
    ny = u.z * v.x - u.x * v.z
    nz = u.x * v.y - u.y * v.x
    n = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return (nx / n, ny / n, nz / n)


def _fill_holes(binary):
    """Solidify a mask: union the figure with its fully enclosed interior gaps."""
    fig = (binary * 255).astype("uint8")
    flood = fig.copy()
    h, w = flood.shape
    cv2.floodFill(flood, np.zeros((h + 2, w + 2), "uint8"), (0, 0), 255)
    return ((fig | cv2.bitwise_not(flood)) > 0).astype("uint8")


# ======================================================================= #
#  read image -> heightfield + albedo grid
# ======================================================================= #
def load_surface(target_h=TARGET_H):
    """Return (height, color, gw, gh) aligned on one grid.

    ``height`` in [0,1] is the inflated relief; ``color`` is the per-cell RGB
    albedo (figure pixels over a dark plinth), both padded by a flat border.
    """
    im = Image.open(SOURCE_IMAGE).convert("RGBA")
    aspect = im.width / im.height
    gw = max(2, round(target_h * aspect))
    gh = target_h

    # composite the figure over the plinth colour so anti-aliased edges blend
    bg = Image.new("RGBA", im.size, PLINTH + (255,))
    flat = Image.alpha_composite(bg, im).convert("RGB")

    # --- geometry at super-resolution (smooth domes) ---------------------- #
    hw, hh = gw * SUPER, gh * SUPER
    alpha_hr = np.asarray(
        im.split()[-1].filter(ImageFilter.GaussianBlur(1.0)).resize((hw, hh), Image.LANCZOS),
        dtype=np.uint8,
    )
    lum_hr = np.asarray(flat.convert("L").resize((hw, hh), Image.LANCZOS), dtype=float) / 255.0
    solid_hr = _fill_holes(alpha_hr > ALPHA_BIN)
    dist = cv2.distanceTransform(solid_hr * 255, cv2.DIST_L2, 5)
    d = dist / max(float(dist.max()), 1e-6)
    dome = np.sqrt(np.clip(2.0 * d - d * d, 0.0, 1.0))
    # shape-from-shading: split luminance into low/high frequency. The low band
    # shapes the big masses (lit torso forward, dark cape sinks toward LUM_FLOOR);
    # the zero-mean high band embosses fine form (muscle, folds, cowl, symbol).
    lo = cv2.GaussianBlur(lum_hr, (0, 0), sigmaX=SUPER * 7.0)
    hp = lum_hr - lo
    body = LUM_FLOOR + (1.0 - LUM_FLOOR) * lo
    relief = np.clip(dome * body + DETAIL_HP * hp * dome, 0.0, None) * solid_hr
    height_hr = cv2.GaussianBlur(relief, (0, 0), sigmaX=SUPER * 0.85)
    height = cv2.resize(height_hr, (gw, gh), interpolation=cv2.INTER_AREA)

    # --- albedo at grid resolution ---------------------------------------- #
    fig = np.asarray(flat.resize((gw, gh), Image.LANCZOS), dtype=float)
    fig = np.clip((fig - 120.0) * CONTRAST + 120.0 + LIFT, 0.0, 255.0)
    mask = cv2.resize(solid_hr.astype(float), (gw, gh), interpolation=cv2.INTER_AREA)
    bgc = np.array(PLINTH, dtype=float)
    color = fig * mask[..., None] + bgc * (1.0 - mask[..., None])

    pad = max(1, round(gh * PAD_FRAC))
    height = np.pad(height, ((pad, pad), (pad, pad)), mode="constant")
    color = np.pad(color, ((pad, pad), (pad, pad), (0, 0)), mode="edge")
    gh, gw = height.shape
    return height, color, gw, gh


# ======================================================================= #
#  build the relief surface (geometry + baked albedo-Lambert shading)
# ======================================================================= #
def build_relief(height, color, gw, gh, eye):
    aspect = gw / gh

    def fn(u, v):
        col = min(gw - 1, max(0, int(round(u))))
        row = min(gh - 1, max(0, int(round(v))))
        x = (u / (gw - 1) - 0.5) * aspect
        y = 0.5 - v / (gh - 1)
        z = float(height[row, col]) * DEPTH
        return (x, y, z)

    scene = Scene3D().parametric_surface(
        fn, u=(0.0, gw - 1), v=(0.0, gh - 1), steps_u=gw - 1, steps_v=gh - 1
    )

    ex, ey, ez = eye.x, eye.y, eye.z
    lx, ly, lz = LIGHT
    for verts, style in scene.faces:
        nx, ny, nz = _face_normal(verts)
        cx = sum(p.x for p in verts) / len(verts)
        cy = sum(p.y for p in verts) / len(verts)
        cz = sum(p.z for p in verts) / len(verts)
        if nx * (ex - cx) + ny * (ey - cy) + nz * (ez - cz) < 0:
            nx, ny, nz = -nx, -ny, -nz
        d = max(0.0, nx * lx + ny * ly + nz * lz)
        b = 0.62 + 0.42 * d                               # keep colour in shadow
        # invert the face centre back to a grid cell to fetch its albedo
        col = min(gw - 1, max(0, int(round((cx / aspect + 0.5) * (gw - 1)))))
        row = min(gh - 1, max(0, int(round((0.5 - cy) * (gh - 1)))))
        style["fill"] = _tint(color[row, col], b)
        style["stroke"] = "none"
    return scene


# ======================================================================= #
#  page
# ======================================================================= #
def build() -> DocumentBuilder:
    hero_h, hero_c, hgw, hgh = load_surface(TARGET_H)
    turn_h, turn_c, tgw, tgh = load_surface(TURN_H)

    b = DocumentBuilder(title="Batman — inflated colour relief", profile="deck", lang="en")
    page = b.page("relief", canvas={"size": [W, H], "units": "px"},
                  coordinate_mode="absolute").layer("bg")
    page.rect([0, 0, W, H], fill=linear_gradient([(BG_TOP, 0), (BG_LOW, 1)], angle=180))

    page.layer("label")
    with page.grouped() as g:
        g.text([60, 44, 920, 34], "Batman — a 3D surface of the render",
               style=dict(font_family=SANS, font_size=26, font_weight=800,
                          color="#E8EEF7", letter_spacing=-0.4))
    with page.grouped() as g:
        g.text([60, 84, 920, 40],
               f"Alpha mask inflated by a distance transform on a {hgw}x{hgh} grid, the "
               "original pixels wrapped on as albedo and Lambert-lit through Scene3D.",
               style=dict(font_family=SANS, font_size=13.5, color=rgba("#E8EEF7", 0.74)))

    page.layer("relief")
    hero_cam = Camera(eye=Vec3(0.42, 0.18, 1.52), target=Vec3(0.0, 0.02, 0.13),
                      fov=31, aspect=HERO_BOX[2] / HERO_BOX[3])
    hero = build_relief(hero_h, hero_c, hgw, hgh, hero_cam.eye)
    page.add(hero.render(box=HERO_BOX, camera=hero_cam, shading="none", id="batman_relief"))

    page.layer("turntable")
    turn = build_relief(turn_h, turn_c, tgw, tgh, hero_cam.eye)
    tb_y = HERO_BOX[1] + HERO_BOX[3] + 30
    tb_w, tb_h, gap = 288, 252, 28
    tb_x0 = (W - 3 * tb_w - 2 * gap) / 2
    for i, az in enumerate(TURN_AZIMUTHS):
        bx = tb_x0 + i * (tb_w + gap)
        page.rect([bx, tb_y, tb_w, tb_h], fill=rgba("#000000", 0.24),
                  stroke=rgba("#E8EEF7", 0.10), stroke_style={"stroke_width": 1.0},
                  radius=10, decorative=True)
        page.add(turn.render(box=[bx, tb_y + 8, tb_w, tb_h - 30],
                             camera=hero_cam.orbit(azimuth=az), shading="none", id=f"turn_{i}"))
        with page.grouped() as g:
            g.text([bx, tb_y + tb_h - 20, tb_w, 14], f"azimuth {az:+.0f}°",
                   style=dict(font_family=MONO, font_size=10.5, text_align="center",
                              color=rgba("#E8EEF7", 0.6)))

    page.layer("caption")
    with page.grouped() as g:
        g.text([60, H - 36, 920, 18],
               "Scene3D.parametric_surface  ·  alpha-mask inflate  ·  original albedo + Lambert",
               style=dict(font_family=MONO, font_size=11, color=rgba("#E8EEF7", 0.55),
                          letter_spacing=0.4))
    return b


def main() -> int:
    b = build()
    doc = b.build()
    report = validate_static_rules(doc)
    errors = [i for i in report.issues if i.severity == "error"]
    warns = [i for i in report.issues if i.severity != "error"]
    print(f"Built {len(doc.pages)} page(s) — ok={report.ok} "
          f"errors={len(errors)} warnings={len(warns)}")
    for i in errors[:20]:
        print(f"  ERROR [{i.rule_id}] {i.path}: {i.message}")
    for i in warns[:10]:
        print(f"  warn  [{i.rule_id}] {i.path}: {i.message}")
    out = os.path.join(ROOT, "fixtures", "batman-3d-surface.fg.yaml")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(serialize(doc, format="yaml"))
    print(f"Wrote {out}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
