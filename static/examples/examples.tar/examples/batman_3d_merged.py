#!/usr/bin/env python3
"""Batman as ONE closed solid — the relief front merged with a solid back.

This merges the two earlier experiments into a single watertight mesh:

  * FRONT  — the inflated, shape-from-shading relief of the colour render
             (``examples/batman_3d_surface.py``), carrying the original pixel
             albedo. This is the recognisable, image-textured face.
  * BACK   — a smooth distance-transform dome pushed to negative Z, giving the
             figure genuine thickness and a real back (the volume the primitive
             build in ``examples/batman_3d_primitives.py`` proved you need).

Both sheets are inflated from the SAME alpha silhouette, so they share a rim and
close into a solid "pillow" of just the figure (background is not emitted). The
result reads as Batman head-on yet orbits a full turn — see the +150° thumbnail.

A closed solid needs correct depth ordering; ``Scene3D.render()`` now sorts
faces near-over-far for perspective cameras (the ``_avg_z`` fix), so we render
through it directly — the shaded fill is baked per face beforehand.

Run from the repository root (the ``vision`` group ships numpy + Pillow + cv2)::

    uv run --group vision  python examples/batman_3d_merged.py
"""
from __future__ import annotations

import math
import os
import sys

import cv2
import numpy as np
from PIL import Image

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, ROOT)
_shadow = sys.modules.get("framegraph")
if _shadow is not None and not hasattr(_shadow, "__path__"):
    del sys.modules["framegraph"]

from framegraph.sdk import (  # noqa: E402
    Camera,
    DocumentBuilder,
    Scene3D,
    Vec3,
    linear_gradient,
    rgba,
    serialize,
)
from framegraph.sdk.validate import validate_static_rules  # noqa: E402

SOURCE_IMAGE = os.path.join(ROOT, "batman__dc__render_v2_by_eternalashen_dkfkwpl-414w-2x.png")

# --- solid tuning --------------------------------------------------------- #
TARGET_H = 120          # grid rows; columns follow the image aspect
SUPER = 3               # super-sample factor for smooth geometry
FRONT_DEPTH = 0.40      # how far the textured relief bulges toward the camera
BACK_DEPTH = 0.34       # how far the plain back shell bulges away
ALPHA_BIN = 40          # alpha above this is "figure"
LUM_FLOOR = 0.45        # low-freq shading floor (dark cape sinks toward this)
DETAIL_HP = 0.90        # high-freq shading embossed as fine front relief
CONTRAST, LIFT = 1.20, 12   # albedo pop on the front face

# --- look ----------------------------------------------------------------- #
W, H = 1040, 1290
HERO_BOX = [60, 138, 920, 800]
TURN_AZIMUTHS = (-40.0, 55.0, 150.0)   # last view is the solid back
SANS = ["DejaVu Sans", "Arial", "sans-serif"]
MONO = ["DejaVu Sans Mono", "Courier New", "monospace"]
BG_TOP, BG_LOW = "#0a0d14", "#141a26"
PLINTH = (16, 18, 26)
BACK_COLOR = (34, 36, 45)        # the plain back-of-suit / inside of the cape

LIGHT = (-0.42, 0.66, 0.62)
_ll = math.sqrt(sum(c * c for c in LIGHT))
LIGHT = tuple(c / _ll for c in LIGHT)


# ======================================================================= #
#  helpers
# ======================================================================= #
def _hex(r, g, b):
    clamp = lambda v: max(0, min(255, int(round(v))))
    return f"#{clamp(r):02X}{clamp(g):02X}{clamp(b):02X}"


def _tint(rgb, b):
    return _hex(rgb[0] * b, rgb[1] * b, rgb[2] * b)


def _face_normal(verts):
    a, b, c = verts[0], verts[1], verts[2]
    u, v = b - a, c - a
    nx = u.y * v.z - u.z * v.y
    ny = u.z * v.x - u.x * v.z
    nz = u.x * v.y - u.y * v.x
    n = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return (nx / n, ny / n, nz / n)


def _fill_holes(binary):
    fig = (binary * 255).astype("uint8")
    flood = fig.copy()
    h, w = flood.shape
    cv2.floodFill(flood, np.zeros((h + 2, w + 2), "uint8"), (0, 0), 255)
    return ((fig | cv2.bitwise_not(flood)) > 0).astype("uint8")


# ======================================================================= #
#  read image -> front relief + back dome + albedo + mask
# ======================================================================= #
def load_solid(target_h=TARGET_H):
    im = Image.open(SOURCE_IMAGE).convert("RGBA")
    aspect_img = im.width / im.height
    gw = max(2, round(target_h * aspect_img))
    gh = target_h
    bg = Image.new("RGBA", im.size, PLINTH + (255,))
    flat = Image.alpha_composite(bg, im).convert("RGB")

    hw, hh = gw * SUPER, gh * SUPER
    alpha_hr = np.asarray(im.split()[-1].resize((hw, hh), Image.LANCZOS), dtype=np.uint8)
    lum_hr = np.asarray(flat.convert("L").resize((hw, hh), Image.LANCZOS), dtype=float) / 255.0
    solid_hr = _fill_holes(alpha_hr > ALPHA_BIN)
    dist = cv2.distanceTransform(solid_hr * 255, cv2.DIST_L2, 5)
    d = dist / max(float(dist.max()), 1e-6)
    dome = np.sqrt(np.clip(2.0 * d - d * d, 0.0, 1.0))

    # FRONT: shape-from-shading relief
    lo = cv2.GaussianBlur(lum_hr, (0, 0), sigmaX=SUPER * 7.0)
    hp = lum_hr - lo
    body = LUM_FLOOR + (1.0 - LUM_FLOOR) * lo
    front_hr = np.clip(dome * body + DETAIL_HP * hp * dome, 0.0, None) * solid_hr
    front_hr = cv2.GaussianBlur(front_hr, (0, 0), sigmaX=SUPER * 0.85)

    # BACK: plain smooth dome
    back_hr = cv2.GaussianBlur(dome * solid_hr, (0, 0), sigmaX=SUPER * 1.2)

    front = cv2.resize(front_hr, (gw, gh), interpolation=cv2.INTER_AREA)
    back = cv2.resize(back_hr, (gw, gh), interpolation=cv2.INTER_AREA)
    mask = cv2.resize(solid_hr.astype(float), (gw, gh), interpolation=cv2.INTER_AREA) > 0.5

    fig = np.asarray(flat.resize((gw, gh), Image.LANCZOS), dtype=float)
    color = np.clip((fig - 120.0) * CONTRAST + 120.0 + LIFT, 0.0, 255.0)

    pad = max(1, round(gh * 0.04))
    z0 = ((pad, pad), (pad, pad))
    front = np.pad(front, z0, mode="constant")
    back = np.pad(back, z0, mode="constant")
    mask = np.pad(mask, z0, mode="constant", constant_values=False)
    color = np.pad(color, z0 + ((0, 0),), mode="edge")
    gh, gw = front.shape
    return front, back, color, mask, gw, gh


# ======================================================================= #
#  build the closed solid (front textured + back shell), shaded in place
# ======================================================================= #
def build_solid(front, back, color, mask, gw, gh):
    aspect = gw / gh
    X = lambda c: (c / (gw - 1) - 0.5) * aspect
    Y = lambda r: 0.5 - r / (gh - 1)
    fv = [[Vec3(X(c), Y(r), FRONT_DEPTH * float(front[r, c])) for c in range(gw)]
          for r in range(gh)]
    bv = [[Vec3(X(c), Y(r), -BACK_DEPTH * float(back[r, c])) for c in range(gw)]
          for r in range(gh)]

    s = Scene3D()
    for r in range(gh - 1):
        for c in range(gw - 1):
            if not (mask[r, c] and mask[r, c + 1] and mask[r + 1, c + 1] and mask[r + 1, c]):
                continue
            col = tuple(color[r, c])
            s.faces.append(([fv[r][c], fv[r][c + 1], fv[r + 1][c + 1], fv[r + 1][c]],
                            {"_albedo": col}))
            s.faces.append(([bv[r][c], bv[r + 1][c], bv[r + 1][c + 1], bv[r][c + 1]],
                            {"_albedo": BACK_COLOR}))
    return s


def shade(scene, eye):
    ex, ey, ez = eye.x, eye.y, eye.z
    lx, ly, lz = LIGHT
    for verts, style in scene.faces:
        nx, ny, nz = _face_normal(verts)
        cx = sum(p.x for p in verts) / len(verts)
        cy = sum(p.y for p in verts) / len(verts)
        cz = sum(p.z for p in verts) / len(verts)
        if nx * (ex - cx) + ny * (ey - cy) + nz * (ez - cz) < 0:
            nx, ny, nz = -nx, -ny, -nz
        d = max(0.0, nx * lx + ny * ly + nz * lz)
        b = 0.50 + 0.50 * d
        style["fill"] = _tint(style.pop("_albedo"), b)
        style["stroke"] = "none"
    return scene


# ======================================================================= #
#  page
# ======================================================================= #
def build() -> DocumentBuilder:
    front, back, color, mask, gw, gh = load_solid(TARGET_H)
    fl, bl, cl, ml, lw, lh = load_solid(64)   # coarse for the turntable

    b = DocumentBuilder(title="Batman — merged closed solid", profile="deck", lang="en")
    page = b.page("solid", canvas={"size": [W, H], "units": "px"},
                  coordinate_mode="absolute").layer("bg")
    page.rect([0, 0, W, H], fill=linear_gradient([(BG_TOP, 0), (BG_LOW, 1)], angle=180))

    page.layer("label")
    with page.grouped() as g:
        g.text([60, 44, 920, 34], "Batman — the relief front merged onto a solid back",
               style=dict(font_family=SANS, font_size=25, font_weight=800,
                          color="#E8EEF7", letter_spacing=-0.4))
    with page.grouped() as g:
        g.text([60, 84, 920, 40],
               "One closed mesh: the image-textured shading relief inflated forward, a smooth "
               "dome inflated back, sharing the alpha silhouette's rim. Recognisable head-on, "
               "yet solid all the way round (+150° = the back).",
               style=dict(font_family=SANS, font_size=13.5, color=rgba("#E8EEF7", 0.74)))

    page.layer("solid")
    hero_cam = Camera(eye=Vec3(0.36, 0.16, 1.56), target=Vec3(0.0, 0.0, 0.0),
                      fov=31, aspect=HERO_BOX[2] / HERO_BOX[3])
    hero = shade(build_solid(front, back, color, mask, gw, gh), hero_cam.eye)
    page.add(hero.render(box=HERO_BOX, camera=hero_cam, shading="none", id="batman_solid"))

    page.layer("turntable")
    turn = shade(build_solid(fl, bl, cl, ml, lw, lh), hero_cam.eye)
    tb_y = HERO_BOX[1] + HERO_BOX[3] + 30
    tb_w, tb_h, gap = 288, 252, 28
    tb_x0 = (W - 3 * tb_w - 2 * gap) / 2
    for i, az in enumerate(TURN_AZIMUTHS):
        bx = tb_x0 + i * (tb_w + gap)
        page.rect([bx, tb_y, tb_w, tb_h], fill=rgba("#000000", 0.24),
                  stroke=rgba("#E8EEF7", 0.10), stroke_style={"stroke_width": 1.0},
                  radius=10, decorative=True)
        page.add(turn.render(box=[bx, tb_y + 8, tb_w, tb_h - 30],
                             camera=hero_cam.orbit(azimuth=az), shading="none", id=f"turn_{i}"))
        with page.grouped() as g:
            g.text([bx, tb_y + tb_h - 20, tb_w, 14], f"azimuth {az:+.0f}°",
                   style=dict(font_family=MONO, font_size=10.5, text_align="center",
                              color=rgba("#E8EEF7", 0.6)))

    page.layer("caption")
    with page.grouped() as g:
        g.text([60, H - 36, 920, 18],
               "front: shading relief + image albedo   ·   back: distance-transform dome   ·   one closed solid",
               style=dict(font_family=MONO, font_size=11, color=rgba("#E8EEF7", 0.55),
                          letter_spacing=0.4))
    return b


def main() -> int:
    b = build()
    doc = b.build()
    report = validate_static_rules(doc)
    errors = [i for i in report.issues if i.severity == "error"]
    warns = [i for i in report.issues if i.severity != "error"]
    print(f"Built {len(doc.pages)} page(s) — ok={report.ok} "
          f"errors={len(errors)} warnings={len(warns)}")
    for i in errors[:20]:
        print(f"  ERROR [{i.rule_id}] {i.path}: {i.message}")
    for i in warns[:10]:
        print(f"  warn  [{i.rule_id}] {i.path}: {i.message}")
    out = os.path.join(ROOT, "fixtures", "batman-3d-merged.fg.yaml")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(serialize(doc, format="yaml"))
    print(f"Wrote {out}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
