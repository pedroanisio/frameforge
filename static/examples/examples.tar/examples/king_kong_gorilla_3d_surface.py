#!/usr/bin/env python3
"""A 3D surface (height-relief) of the King Kong gorilla stencil — built with the SDK.

The input is the black-on-white gorilla JPG at the repository root. We read its
luminance, treat *darkness as height* (black ink rises, white background stays
flat), and feed that heightfield to :meth:`framegraph.sdk.Scene3D.parametric_surface`
as a graph ``z = f(x, y)``. The mesh is projected through a perspective
:class:`Camera`, exactly like ``examples/sdk_3d_scene.py``.

Because the surface is a single-valued heightfield (no overhangs), the painter's
algorithm in :meth:`Scene3D.render` sorts it cleanly. Shading is baked author-side
over the public ``Scene3D.faces`` list: a height ramp (slab → highlight) multiplied
by a Lambert term, so the gorilla reads as a cast bronze bas-relief standing upright.

Run from the repository root (the ``vision`` group ships numpy + Pillow)::

    uv run --group vision python examples/king_kong_gorilla_3d_surface.py
"""
from __future__ import annotations

import math
import os
import sys

import cv2
import numpy as np
from PIL import Image, ImageFilter

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, ROOT)
_shadow = sys.modules.get("framegraph")
if _shadow is not None and not hasattr(_shadow, "__path__"):
    del sys.modules["framegraph"]

from framegraph.sdk import (  # noqa: E402
    Camera,
    DocumentBuilder,
    Scene3D,
    Vec3,
    linear_gradient,
    rgba,
    serialize,
)
from framegraph.sdk.validate import validate_static_rules  # noqa: E402

SOURCE_IMAGE = os.path.join(ROOT, "71mwPUhFXqL._AC_UF894,1000_QL80_.jpg")

# --- relief tuning -------------------------------------------------------- #
TARGET_H = 122          # heightfield rows; columns follow the image aspect
SUPER = 3               # super-sample factor for a smooth distance transform
DEPTH = 0.40            # relief depth as a fraction of the unit Y span
INK_BIN = 0.42          # ink above this is "figure" for the silhouette mask
GROOVE = 0.34           # how deeply interior white lines carve the domed body
PAD_FRAC = 0.05         # zero-height border so the relief sits on a plaque

# --- look ----------------------------------------------------------------- #
W, H = 1040, 1280
HERO_BOX = [60, 138, 920, 800]
TURN_H = 60             # coarse grid for the turntable thumbnails
TURN_AZIMUTHS = (-30.0, 0.0, 30.0)
SANS = ["DejaVu Sans", "Arial", "sans-serif"]
MONO = ["DejaVu Sans Mono", "Courier New", "monospace"]
BG_TOP, BG_LOW = "#0a0e16", "#161d2b"
RAMP_LOW = "#15110a"    # the slab / deep background of the relief
RAMP_HIGH = "#f0c270"   # lit bronze highlight on the tallest ridges

LIGHT = (-0.42, 0.72, 0.55)
_ll = math.sqrt(sum(c * c for c in LIGHT))
LIGHT = tuple(c / _ll for c in LIGHT)


# ======================================================================= #
#  colour helpers
# ======================================================================= #
def _rgb(hexc):
    h = hexc.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _hex(r, g, b):
    clamp = lambda v: max(0, min(255, int(round(v))))
    return f"#{clamp(r):02X}{clamp(g):02X}{clamp(b):02X}"


def _ramp(t):
    """Linear blend RAMP_LOW -> RAMP_HIGH for height fraction t in [0, 1]."""
    lr, lg, lb = _rgb(RAMP_LOW)
    hr, hg, hb = _rgb(RAMP_HIGH)
    t = max(0.0, min(1.0, t))
    return (lr + (hr - lr) * t, lg + (hg - lg) * t, lb + (hb - lb) * t)


def _tint(rgb, b):
    r, g, bl = rgb
    return _hex(r * b, g * b, bl * b)


def _face_normal(verts):
    a, b, c = verts[0], verts[1], verts[2]
    u, v = b - a, c - a
    nx = u.y * v.z - u.z * v.y
    ny = u.z * v.x - u.x * v.z
    nz = u.x * v.y - u.y * v.x
    n = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return (nx / n, ny / n, nz / n)


# ======================================================================= #
#  read image -> heightfield
# ======================================================================= #
def _fill_holes(binary):
    """Solidify a silhouette: union the figure with its enclosed interior
    regions (the white muscle striations) so the body is one mass. Flood the
    exterior background from a corner, invert to isolate interior holes, OR in.
    """
    fig = (binary * 255).astype("uint8")
    flood = fig.copy()
    h, w = flood.shape
    cv2.floodFill(flood, np.zeros((h + 2, w + 2), "uint8"), (0, 0), 255)
    holes = cv2.bitwise_not(flood)                         # interior bg -> 255
    return ((fig | holes) > 0).astype("uint8")


def load_heightfield(target_h=TARGET_H):
    """Black ink -> an *inflated* relief.

    A flat silhouette can't be a flat plateau and still read as a body, so we
    inflate it: a Euclidean distance transform over the solidified silhouette
    gives each region's distance-to-edge, and a hemispherical transfer
    ``z = sqrt(2d - d^2)`` puffs thin parts into rounded tubes and thick parts
    into domes — torso, arms and head bulge toward the viewer. The transform is
    computed super-sampled (smooth domes, no terracing) then reduced to the mesh
    grid; interior white lines are carved back in as grooves so the brow, muzzle
    and muscle striations survive the inflation.
    """
    img = Image.open(SOURCE_IMAGE).convert("L")
    aspect = img.width / img.height
    gw = max(2, round(target_h * aspect))
    gh = target_h
    img = img.filter(ImageFilter.GaussianBlur(0.8))

    # --- high-resolution pass (smooth geometry) --------------------------- #
    hw, hh = gw * SUPER, gh * SUPER
    lum_hr = np.asarray(img.resize((hw, hh), Image.LANCZOS), dtype=float) / 255.0
    ink_hr = 1.0 - lum_hr
    solid_hr = _fill_holes(ink_hr > INK_BIN)
    dist = cv2.distanceTransform(solid_hr * 255, cv2.DIST_L2, 5)
    d = dist / max(float(dist.max()), 1e-6)                # 0 at edge .. 1 core
    dome = np.sqrt(np.clip(2.0 * d - d * d, 0.0, 1.0))     # hemispherical puff
    # carve interior white striations (lum high *inside* the figure) as grooves
    height_hr = dome * (1.0 - GROOVE * solid_hr * lum_hr) * solid_hr
    height_hr = cv2.GaussianBlur(height_hr, (0, 0), sigmaX=SUPER * 0.9)

    # --- reduce to the mesh grid ------------------------------------------ #
    height = cv2.resize(height_hr, (gw, gh), interpolation=cv2.INTER_AREA)

    pad = max(1, round(gh * PAD_FRAC))
    height = np.pad(height, ((pad, pad), (pad, pad)), mode="constant")
    gh, gw = height.shape
    return height, gw, gh


# ======================================================================= #
#  build the relief surface
# ======================================================================= #
def build_relief(height, gw, gh, eye):
    aspect = gw / gh

    def fn(u, v):
        col = int(round(u))
        row = int(round(v))
        col = 0 if col < 0 else (gw - 1 if col > gw - 1 else col)
        row = 0 if row < 0 else (gh - 1 if row > gh - 1 else row)
        h = float(height[row, col])
        x = (u / (gw - 1) - 0.5) * aspect
        y = 0.5 - v / (gh - 1)                            # row 0 (top) -> +Y
        z = h * DEPTH
        return (x, y, z)

    scene = Scene3D().parametric_surface(
        fn, u=(0.0, gw - 1), v=(0.0, gh - 1), steps_u=gw - 1, steps_v=gh - 1
    )

    # author-side shading over the public face list
    ex, ey, ez = eye.x, eye.y, eye.z
    lx, ly, lz = LIGHT
    for verts, style in scene.faces:
        nx, ny, nz = _face_normal(verts)
        cx = sum(p.x for p in verts) / len(verts)
        cy = sum(p.y for p in verts) / len(verts)
        cz = sum(p.z for p in verts) / len(verts)
        if nx * (ex - cx) + ny * (ey - cy) + nz * (ez - cz) < 0:
            nx, ny, nz = -nx, -ny, -nz
        d = max(0.0, nx * lx + ny * ly + nz * lz)
        b = 0.30 + 0.70 * d                               # ambient + diffuse
        t = cz / DEPTH                                    # height fraction
        style["fill"] = _tint(_ramp(t), b)
        style["stroke"] = "none"
    return scene


# ======================================================================= #
#  page
# ======================================================================= #
def build() -> DocumentBuilder:
    hero_h, hgw, hgh = load_heightfield(TARGET_H)
    turn_h, tgw, tgh = load_heightfield(TURN_H)

    b = DocumentBuilder(title="King Kong — heightfield relief", profile="deck", lang="en")
    page = b.page("relief", canvas={"size": [W, H], "units": "px"},
                  coordinate_mode="absolute").layer("bg")
    page.rect([0, 0, W, H], fill=linear_gradient([(BG_TOP, 0), (BG_LOW, 1)], angle=180))

    page.layer("label")
    with page.grouped() as g:
        g.text([60, 44, 920, 34], "King Kong — a 3D surface of the stencil",
               style=dict(font_family=SANS, font_size=26, font_weight=800,
                          color="#F4E7C8", letter_spacing=-0.4))
    with page.grouped() as g:
        g.text([60, 84, 920, 40],
               f"Silhouette inflated by a distance transform on a {hgw}x{hgh} grid and "
               "projected as a graph z = f(x, y) through Scene3D + a perspective Camera.",
               style=dict(font_family=SANS, font_size=13.5, color=rgba("#F4E7C8", 0.74)))

    # hero view -------------------------------------------------------------- #
    page.layer("relief")
    hero_cam = Camera(eye=Vec3(0.44, 0.20, 1.50), target=Vec3(0.0, 0.02, 0.12),
                      fov=31, aspect=HERO_BOX[2] / HERO_BOX[3])
    hero = build_relief(hero_h, hgw, hgh, hero_cam.eye)
    page.add(hero.render(box=HERO_BOX, camera=hero_cam, shading="none", id="gorilla_relief"))

    # turntable strip — the SAME geometry under a fixed light, orbited so the
    # rounded volume is visible from several angles (the proof it is a surface).
    page.layer("turntable")
    turn = build_relief(turn_h, tgw, tgh, hero_cam.eye)
    tb_y = HERO_BOX[1] + HERO_BOX[3] + 28
    tb_w, tb_h, gap = 288, 252, 28
    tb_x0 = (W - 3 * tb_w - 2 * gap) / 2
    for i, az in enumerate(TURN_AZIMUTHS):
        bx = tb_x0 + i * (tb_w + gap)
        page.rect([bx, tb_y, tb_w, tb_h], fill=rgba("#000000", 0.22),
                  stroke=rgba("#F4E7C8", 0.10), stroke_style={"stroke_width": 1.0},
                  radius=10, decorative=True)
        cam = hero_cam.orbit(azimuth=az)
        page.add(turn.render(box=[bx, tb_y + 8, tb_w, tb_h - 30], camera=cam,
                             shading="none", id=f"turn_{i}"))
        with page.grouped() as g:
            g.text([bx, tb_y + tb_h - 20, tb_w, 14], f"azimuth {az:+.0f}°",
                   style=dict(font_family=MONO, font_size=10.5, text_align="center",
                              color=rgba("#F4E7C8", 0.6)))

    page.layer("caption")
    with page.grouped() as g:
        g.text([60, H - 36, 920, 18],
               "Scene3D.parametric_surface  ·  distance-transform inflate  ·  Lambert + height-ramp bronze",
               style=dict(font_family=MONO, font_size=11, color=rgba("#F4E7C8", 0.55),
                          letter_spacing=0.4))
    return b


def main() -> int:
    b = build()
    doc = b.build()
    report = validate_static_rules(doc)
    errors = [i for i in report.issues if i.severity == "error"]
    warns = [i for i in report.issues if i.severity != "error"]
    print(f"Built {len(doc.pages)} page(s) — ok={report.ok} "
          f"errors={len(errors)} warnings={len(warns)}")
    for i in errors[:20]:
        print(f"  ERROR [{i.rule_id}] {i.path}: {i.message}")
    for i in warns[:10]:
        print(f"  warn  [{i.rule_id}] {i.path}: {i.message}")
    out = os.path.join(ROOT, "fixtures", "king-kong-gorilla-3d-surface.fg.yaml")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(serialize(doc, format="yaml"))
    print(f"Wrote {out}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
