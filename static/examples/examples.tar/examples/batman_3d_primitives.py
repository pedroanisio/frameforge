#!/usr/bin/env python3
"""A *blocked-in* 3D Batman, built from solid primitives — FrameGraph SDK.

This is the honest answer to "fill it with 3D forms". A single image cannot be
*reconstructed* into a full volumetric model (no back, no occluded geometry), so
instead we *construct* one the way a sculptor blocks in a mannequin: a kit of
solid primitives (ellipsoids, rotated capsules, a belt band, a curved cape sheet)
is proportioned from landmarks measured off the render's alpha mask, and each
primitive is auto-coloured by sampling the original pixels under its footprint.

Because every primitive is a closed solid, the figure has a genuine back and can
be orbited a full turn — the turntable strip includes a rear three-quarter view
to prove it. The proportions come from the image; the volume is invented generic
anatomy. That distinction is the whole point: construction, not reconstruction.

Run from the repository root (the ``vision`` group ships numpy + Pillow + cv2)::

    uv run --group vision  python examples/batman_3d_primitives.py
"""
from __future__ import annotations

import math
import os
import sys

import numpy as np
from PIL import Image

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, ROOT)
_shadow = sys.modules.get("framegraph")
if _shadow is not None and not hasattr(_shadow, "__path__"):
    del sys.modules["framegraph"]

from framegraph.sdk import (  # noqa: E402
    Camera,
    DocumentBuilder,
    Scene3D,
    Vec3,
    linear_gradient,
    rgba,
    serialize,
)
from framegraph.sdk.validate import validate_static_rules  # noqa: E402

SOURCE_IMAGE = os.path.join(ROOT, "batman__dc__render_v2_by_eternalashen_dkfkwpl-414w-2x.png")

# --- figure landmarks (measured from the alpha mask) ---------------------- #
ASPECT = 827 / 999      # image width / height
TOP_N, HF_N = 0.071, 0.928   # figure top (norm) and height (norm of image H)
CX = 0.49               # figure centre column (norm)

# --- look ----------------------------------------------------------------- #
W, H = 1040, 1290
HERO_BOX = [60, 138, 920, 800]
TURN_AZIMUTHS = (-45.0, 50.0, 150.0)   # last view is rear-three-quarter
SANS = ["DejaVu Sans", "Arial", "sans-serif"]
MONO = ["DejaVu Sans Mono", "Courier New", "monospace"]
BG_TOP, BG_LOW = "#0a0d14", "#141a26"

# semantic fallback palette (used when a footprint samples too few pixels)
COWL, SUIT, BELT, CAPE = (26, 27, 31), (96, 101, 98), (188, 152, 66), (17, 17, 22)

LIGHT = (-0.42, 0.66, 0.62)
_ll = math.sqrt(sum(c * c for c in LIGHT))
LIGHT = tuple(c / _ll for c in LIGHT)


# ======================================================================= #
#  coordinate helpers — normalise everything by image height (isotropic)
# ======================================================================= #
def wx(nx):                       # column fraction -> world x
    return (nx - CX) * ASPECT


def wy(f):                        # figure fraction (0 top .. 1 bottom) -> world y
    return 0.5 - (TOP_N + f * HF_N)


def rx_(w):                       # width fraction (of image) -> world x-radius
    return 0.5 * w * ASPECT


def ry_(f):                       # figure fraction -> world y-radius
    return 0.5 * f * HF_N


# ======================================================================= #
#  colour helpers
# ======================================================================= #
def _hex(r, g, b):
    clamp = lambda v: max(0, min(255, int(round(v))))
    return f"#{clamp(r):02X}{clamp(g):02X}{clamp(b):02X}"


def _tint(rgb, b):
    return _hex(rgb[0] * b, rgb[1] * b, rgb[2] * b)


def _face_normal(verts):
    a, b, c = verts[0], verts[1], verts[2]
    u, v = b - a, c - a
    nx = u.y * v.z - u.z * v.y
    ny = u.z * v.x - u.x * v.z
    nz = u.x * v.y - u.y * v.x
    n = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return (nx / n, ny / n, nz / n)


class Sampler:
    """Median image colour under a primitive's footprint (figure pixels only)."""

    def __init__(self):
        im = Image.open(SOURCE_IMAGE).convert("RGBA")
        self.W, self.H = im.size
        a = np.asarray(im)
        self.rgb = a[..., :3].astype(float)
        self.m = a[..., 3] > 40

    def at(self, nx, f, rad=0.05, fallback=SUIT):
        col = int(nx * self.W)
        row = int((TOP_N + f * HF_N) * self.H)
        rp = max(2, int(rad * self.W))
        r0, r1 = max(0, row - rp), min(self.H, row + rp)
        c0, c1 = max(0, col - rp), min(self.W, col + rp)
        sub_m = self.m[r0:r1, c0:c1]
        sub = self.rgb[r0:r1, c0:c1][sub_m]
        if len(sub) < 12:
            return fallback
        return tuple(float(v) for v in np.median(sub, 0))


# ======================================================================= #
#  primitive builders (each appends faces carrying an `_albedo` style)
# ======================================================================= #
def ellipsoid(scene, center, radii, albedo, *, rot=0.0, nu=22, nv=14):
    cx, cy, cz = center
    a, b, c = radii
    ct, st = math.cos(rot), math.sin(rot)

    def f(u, v):
        x = a * math.sin(v) * math.cos(u)
        y = b * math.cos(v)
        z = c * math.sin(v) * math.sin(u)
        return (cx + x * ct - y * st, cy + x * st + y * ct, cz + z)

    scene.parametric_surface(f, u=(0.0, 2 * math.pi), v=(0.0, math.pi),
                             steps_u=nu, steps_v=nv, _albedo=albedo)


def cone(scene, apex, base_center, base_r, albedo, *, nu=14):
    ax, ay, az = apex
    bx, by, bz = base_center

    def f(u, v):  # v: 0 base .. 1 apex
        ang = u
        r = base_r * (1.0 - v)
        x = bx + r * math.cos(ang) + (ax - bx) * v
        y = by + (ay - by) * v
        z = bz + r * math.sin(ang) + (az - bz) * v
        return (x, y, z)

    scene.parametric_surface(f, u=(0.0, 2 * math.pi), v=(0.0, 1.0),
                             steps_u=nu, steps_v=6, _albedo=albedo)


def cape(scene, albedo, *, nu=28, nv=20):
    def f(u, v):  # u in [-1,1] across, v in [0,1] down
        top, length = wy(0.27), 0.66
        half = rx_(0.27) * (1.0 + 0.45 * v)              # widen downward
        x = wx(CX) + half * u
        y = top - length * v
        z = -0.13 - 0.18 * v - 0.05 * u * u              # always behind the body
        return (x, y, z)

    scene.parametric_surface(f, u=(-1.0, 1.0), v=(0.0, 1.0),
                             steps_u=nu, steps_v=nv, _albedo=albedo)


# ======================================================================= #
#  assemble the figure
# ======================================================================= #
def build_figure(sampler, res=1.0):
    s = Scene3D()
    nu = max(10, int(22 * res)); nv = max(8, int(14 * res))
    ell = lambda c, r, col, **k: ellipsoid(s, c, r, col, nu=nu, nv=nv, **k)

    # cape first (drawn behind) ------------------------------------------- #
    cape(s, CAPE, nu=max(16, int(30 * res)), nv=max(12, int(22 * res)))

    # cowl ears ----------------------------------------------------------- #
    cone(s, (wx(0.40), wy(-0.07), 0.02), (wx(0.41), wy(0.06), 0.02), rx_(0.035), COWL, nu=10)
    cone(s, (wx(0.555), wy(-0.07), 0.02), (wx(0.545), wy(0.06), 0.02), rx_(0.035), COWL, nu=10)

    # head / cowl --------------------------------------------------------- #
    ell((wx(0.452), wy(0.125), 0.05), (rx_(0.21), ry_(0.21), 0.115), COWL)
    # neck — wide + tall so it bridges head to shoulders (no gap) ---------- #
    ell((wx(0.458), wy(0.255), 0.0), (rx_(0.15), ry_(0.115), 0.10), (58, 62, 60))

    # shoulders / traps (overlap the neck and torso) ---------------------- #
    ell((wx(0.355), wy(0.33), -0.01), (rx_(0.20), ry_(0.16), 0.12), sampler.at(0.36, 0.31))
    ell((wx(0.635), wy(0.33), -0.01), (rx_(0.20), ry_(0.16), 0.12), sampler.at(0.63, 0.31))

    # torso: chest -> abs -> lower belly (tapering, full-depth solids) ---- #
    ell((wx(0.49), wy(0.42), 0.0), (rx_(0.32), ry_(0.18), 0.15), sampler.at(0.49, 0.41))
    ell((wx(0.49), wy(0.57), 0.0), (rx_(0.28), ry_(0.16), 0.135), sampler.at(0.49, 0.56))
    ell((wx(0.49), wy(0.68), 0.0), (rx_(0.24), ry_(0.11), 0.115), sampler.at(0.49, 0.67))

    # pecs, seated just proud of the chest so they read but don't float ---- #
    ell((wx(0.42), wy(0.41), 0.085), (rx_(0.115), ry_(0.08), 0.07), sampler.at(0.42, 0.41))
    ell((wx(0.56), wy(0.41), 0.085), (rx_(0.115), ry_(0.08), 0.07), sampler.at(0.56, 0.41))
    # chest bat-symbol, seated proud so it reads on the sternum ------------ #
    ell((wx(0.49), wy(0.47), 0.155), (rx_(0.15), ry_(0.05), 0.02), (12, 12, 16))

    # upper arms (rotated capsules angling out & down) -------------------- #
    ell((wx(0.305), wy(0.47), 0.0), (rx_(0.095), ry_(0.19), 0.095),
        sampler.at(0.30, 0.46), rot=+0.42)
    ell((wx(0.695), wy(0.47), 0.0), (rx_(0.095), ry_(0.19), 0.095),
        sampler.at(0.70, 0.46), rot=-0.42)
    # forearms / gauntlets, brought forward
    ell((wx(0.27), wy(0.65), 0.05), (rx_(0.08), ry_(0.14), 0.085),
        sampler.at(0.26, 0.64), rot=+0.30)
    ell((wx(0.73), wy(0.65), 0.05), (rx_(0.08), ry_(0.14), 0.085),
        sampler.at(0.74, 0.64), rot=-0.30)

    # belt band ----------------------------------------------------------- #
    ell((wx(0.49), wy(0.745), 0.03), (rx_(0.26), ry_(0.04), 0.115),
        sampler.at(0.49, 0.95, 0.04, fallback=BELT))
    return s


# ======================================================================= #
#  baked Lambert shading over the primitive faces
# ======================================================================= #
def shade(scene, eye):
    ex, ey, ez = eye.x, eye.y, eye.z
    lx, ly, lz = LIGHT
    for verts, style in scene.faces:
        nx, ny, nz = _face_normal(verts)
        cx = sum(p.x for p in verts) / len(verts)
        cy = sum(p.y for p in verts) / len(verts)
        cz = sum(p.z for p in verts) / len(verts)
        if nx * (ex - cx) + ny * (ey - cy) + nz * (ez - cz) < 0:
            nx, ny, nz = -nx, -ny, -nz
        d = max(0.0, nx * lx + ny * ly + nz * lz)
        b = 0.52 + 0.48 * d
        style["fill"] = _tint(style.pop("_albedo", SUIT), b)
        style["stroke"] = "none"
    return scene


# ======================================================================= #
#  page
# ======================================================================= #
def build() -> DocumentBuilder:
    sampler = Sampler()

    b = DocumentBuilder(title="Batman — blocked-in primitives", profile="deck", lang="en")
    page = b.page("figure", canvas={"size": [W, H], "units": "px"},
                  coordinate_mode="absolute").layer("bg")
    page.rect([0, 0, W, H], fill=linear_gradient([(BG_TOP, 0), (BG_LOW, 1)], angle=180))

    page.layer("label")
    with page.grouped() as g:
        g.text([60, 44, 920, 34], "Batman — blocked in from solid 3D forms",
               style=dict(font_family=SANS, font_size=26, font_weight=800,
                          color="#E8EEF7", letter_spacing=-0.4))
    with page.grouped() as g:
        g.text([60, 84, 920, 40],
               "Ellipsoids, capsules, a belt band and a curved cape sheet — proportioned "
               "from the render's alpha mask, auto-coloured from its pixels. Solid, so it "
               "has a back (see the +150° view).",
               style=dict(font_family=SANS, font_size=13.5, color=rgba("#E8EEF7", 0.74)))

    page.layer("figure")
    hero_cam = Camera(eye=Vec3(0.30, 0.14, 1.66), target=Vec3(0.0, -0.02, 0.0),
                      fov=30, aspect=HERO_BOX[2] / HERO_BOX[3])
    hero = shade(build_figure(sampler, res=1.0), hero_cam.eye)
    page.add(hero.render(box=HERO_BOX, camera=hero_cam, shading="none", id="batman_figure"))

    page.layer("turntable")
    turn = shade(build_figure(sampler, res=0.6), hero_cam.eye)
    tb_y = HERO_BOX[1] + HERO_BOX[3] + 30
    tb_w, tb_h, gap = 288, 252, 28
    tb_x0 = (W - 3 * tb_w - 2 * gap) / 2
    for i, az in enumerate(TURN_AZIMUTHS):
        bx = tb_x0 + i * (tb_w + gap)
        page.rect([bx, tb_y, tb_w, tb_h], fill=rgba("#000000", 0.24),
                  stroke=rgba("#E8EEF7", 0.10), stroke_style={"stroke_width": 1.0},
                  radius=10, decorative=True)
        page.add(turn.render(box=[bx, tb_y + 8, tb_w, tb_h - 30],
                             camera=hero_cam.orbit(azimuth=az), shading="none", id=f"turn_{i}"))
        with page.grouped() as g:
            g.text([bx, tb_y + tb_h - 20, tb_w, 14], f"azimuth {az:+.0f}°",
                   style=dict(font_family=MONO, font_size=10.5, text_align="center",
                              color=rgba("#E8EEF7", 0.6)))

    page.layer("caption")
    with page.grouped() as g:
        g.text([60, H - 36, 920, 18],
               "Scene3D primitives  ·  proportions from the alpha mask  ·  albedo from the pixels  ·  full solid volume",
               style=dict(font_family=MONO, font_size=11, color=rgba("#E8EEF7", 0.55),
                          letter_spacing=0.4))
    return b


def main() -> int:
    b = build()
    doc = b.build()
    report = validate_static_rules(doc)
    errors = [i for i in report.issues if i.severity == "error"]
    warns = [i for i in report.issues if i.severity != "error"]
    print(f"Built {len(doc.pages)} page(s) — ok={report.ok} "
          f"errors={len(errors)} warnings={len(warns)}")
    for i in errors[:20]:
        print(f"  ERROR [{i.rule_id}] {i.path}: {i.message}")
    for i in warns[:10]:
        print(f"  warn  [{i.rule_id}] {i.path}: {i.message}")
    out = os.path.join(ROOT, "fixtures", "batman-3d-primitives.fg.yaml")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(serialize(doc, format="yaml"))
    print(f"Wrote {out}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
